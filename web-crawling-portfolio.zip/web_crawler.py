import csv
import time
from collections import deque
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

START_URL = "https://example.com/"
MAX_PAGES = 10
DELAY_SECONDS = 1

HEADERS = {
    "User-Agent": "Starlutomia-Portfolio-Crawler/1.0 (educational project)"
}


def allowed_by_robots(url):
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    rp = RobotFileParser(robots_url)
    try:
        rp.read()
        return rp.can_fetch(HEADERS["User-Agent"], url)
    except Exception:
        return False


def crawl(start_url):
    domain = urlparse(start_url).netloc
    queue = deque([start_url])
    visited = set()
    records = []

    while queue and len(visited) < MAX_PAGES:
        url = queue.popleft()

        if url in visited or urlparse(url).netloc != domain:
            continue

        if not allowed_by_robots(url):
            print(f"Skipping (robots.txt): {url}")
            visited.add(url)
            continue

        try:
            response = requests.get(url, headers=HEADERS, timeout=10)
            response.raise_for_status()
        except requests.RequestException as exc:
            print(f"Could not fetch {url}: {exc}")
            visited.add(url)
            continue

        visited.add(url)
        soup = BeautifulSoup(response.text, "html.parser")

        title = soup.title.get_text(" ", strip=True) if soup.title else ""
        records.append({
            "url": url,
            "title": title,
            "status_code": response.status_code
        })

        for link in soup.find_all("a", href=True):
            next_url = urljoin(url, link["href"]).split("#")[0]
            if urlparse(next_url).netloc == domain and next_url not in visited:
                queue.append(next_url)

        time.sleep(DELAY_SECONDS)

    return records


if __name__ == "__main__":
    data = crawl(START_URL)

    with open("crawled_data.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["url", "title", "status_code"])
        writer.writeheader()
        writer.writerows(data)

    print(f"Saved {len(data)} records to crawled_data.csv")
