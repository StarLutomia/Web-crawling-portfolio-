# Public Website Data Crawler

A beginner-friendly Python web crawling project that collects structured information from a public website and saves the results as CSV data.

## Skills demonstrated
- Python
- HTTP requests
- HTML parsing with BeautifulSoup
- Link discovery
- Data extraction and cleaning
- Duplicate handling
- CSV export
- Basic error handling
- Respecting robots.txt and crawl-friendly practices

## Project structure
- `web_crawler.py` - crawler script
- `sample_data.csv` - example output
- `requirements.txt` - Python dependencies

## How to run

```bash
pip install -r requirements.txt
python web_crawler.py
```

The script is designed as a learning/demo project. Before crawling any website, check its robots.txt, terms of use, and applicable rules. Keep request rates low and only collect publicly available information that you are permitted to access.

## Portfolio summary

Built a Python-based web crawler that discovers pages from a starting URL, extracts structured information, removes duplicate records, and exports the results to CSV. The project demonstrates attention to data quality, basic web technologies, and systematic online research.
